/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "js_device_abstract_helper.h"
#include "window_manager_hilog.h"
#include "js_runtime_utils.h"

namespace OHOS::Rosen {

constexpr HiviewDFX::HiLogLabel LABEL = {LOG_CORE, HILOG_DOMAIN_WINDOW, "JsDeviceAbstract"};

JsDeviceAbstractHelper& JsDeviceAbstractHelper::GetInstance()
{
    static JsDeviceAbstractHelper instance;
    return instance;
}

JsDeviceAbstractHelper::~JsDeviceAbstractHelper()
{
    std::lock_guard<std::mutex> lock(napiMutex_);
    env_ = nullptr;
    jsModuleRef_ = nullptr;
    getInstanceFuncRef_ = nullptr;
}

void JsDeviceAbstractHelper::Initialize(napi_env env)
{
    if (env == nullptr) {
        TLOGE(LABEL, "NAPI env is null");
        return;
    }
    
    std::lock_guard<std::mutex> lock(napiMutex_);
    
    if (initialized_) {
        TLOGW(LABEL, "Already initialized");
        return;
    }
    
    env_ = env;
    
    // 1. 加载 JS 模块（假设模块名为 @ohos.device.abstract.helper）
    napi_value moduleObj = nullptr;
    napi_status status = napi_require(env, "@ohos.device.abstract.helper", &moduleObj);
    if (status != napi_ok || moduleObj == nullptr) {
        TLOGW(LABEL, "Failed to load JS module, will use fallback mode");
        return;
    }
    
    // 2. 创建模块引用（避免被 GC 回收）
    napi_ref moduleRef = nullptr;
    napi_create_reference(env, moduleObj, 1, &moduleRef);
    jsModuleRef_ = std::make_shared<NativeReference>(env, moduleRef);
    
    // 3. 获取 getInstance 静态方法
    napi_value getInstanceFunc = nullptr;
    status = napi_get_named_property(env, moduleObj, "getInstance", &getInstanceFunc);
    if (status != napi_ok || getInstanceFunc == nullptr) {
        TLOGE(LABEL, "Failed to get getInstance function");
        return;
    }
    
    // 4. 创建函数引用
    napi_ref funcRef = nullptr;
    napi_create_reference(env, getInstanceFunc, 1, &funcRef);
    getInstanceFuncRef_ = std::make_shared<NativeReference>(env, funcRef);
    
    initialized_ = true;
    TLOGI(LABEL, "JsDeviceAbstractHelper initialized successfully");
}

napi_value JsDeviceAbstractHelper::GetJSInstance(napi_env env)
{
    if (!initialized_ || getInstanceFuncRef_ == nullptr) {
        TLOGE(LABEL, "Not initialized or getInstance function is null");
        return nullptr;
    }
    
    // 获取 getInstance 函数
    napi_value getInstanceFunc = nullptr;
    napi_status status = napi_get_reference_value(env, getInstanceFuncRef_->GetNativeReference(), &getInstanceFunc);
    if (status != napi_ok || getInstanceFunc == nullptr) {
        TLOGE(LABEL, "Failed to get getInstance function reference");
        return nullptr;
    }
    
    // 调用 getInstance() - 静态方法，this 为 null
    napi_value global = nullptr;
    napi_get_global(env, &global);
    
    napi_value instance = nullptr;
    status = napi_call_function(
        env,
        global,
        getInstanceFunc,
        0,      // 参数个数
        nullptr,// 参数数组
        &instance
    );
    
    if (status != napi_ok || instance == nullptr) {
        TLOGE(LABEL, "Failed to call getInstance()");
        return nullptr;
    }
    
    return instance;
}

SelectMode JsDeviceAbstractHelper::CallGetSelectMode(napi_env env, napi_value instance)
{
    if (instance == nullptr) {
        TLOGE(LABEL, "Instance is null");
        return SelectMode::INVALID;
    }
    
    // 获取 getSelectMode 方法
    napi_value getSelectModeFunc = nullptr;
    napi_status status = napi_get_named_property(env, instance, "getSelectMode", &getSelectModeFunc);
    if (status != napi_ok || getSelectModeFunc == nullptr) {
        TLOGE(LABEL, "Failed to get getSelectMode method");
        return SelectMode::INVALID;
    }
    
    // 调用 getSelectMode()
    napi_value result = nullptr;
    status = napi_call_function(
        env,
        instance,  // this 对象
        getSelectModeFunc,
        0,         // 参数个数
        nullptr,   // 参数数组
        &result
    );
    
    if (status != napi_ok || result == nullptr) {
        TLOGE(LABEL, "Failed to call getSelectMode()");
        return SelectMode::INVALID;
    }
    
    // 获取返回值（枚举值）
    int32_t modeValue = 0;
    status = napi_get_value_int32(env, result, &modeValue);
    if (status != napi_ok) {
        TLOGE(LABEL, "Failed to get return value");
        return SelectMode::INVALID;
    }
    
    auto mode = static_cast<SelectMode>(modeValue);
    TLOGD(LABEL, "JS returned SelectMode: %{public}d (%{public}s)", 
          modeValue, GetSelectModeString(mode).c_str());
    
    return mode;
}

SelectMode JsDeviceAbstractHelper::GetSelectMode()
{
    // 如果未初始化或 NAPI 环境无效，返回缓存的值或默认值
    if (!initialized_ || env_ == nullptr) {
        SelectMode cached = currentMode_.load();
        if (cached != SelectMode::INVALID) {
            return cached;
        }
        TLOGW(LABEL, "JsDeviceAbstractHelper not initialized yet, using default WIDE mode");
        return SelectMode::WIDE;
    }
    
    std::lock_guard<std::mutex> lock(napiMutex_);
    
    // 调用 JS 侧获取最新的 SelectMode
    napi_value instance = GetJSInstance(env_);
    if (instance == nullptr) {
        TLOGW(LABEL, "Failed to get JS instance, using cached value");
        SelectMode cached = currentMode_.load();
        return (cached != SelectMode::INVALID) ? cached : SelectMode::WIDE;
    }
    
    SelectMode newMode = CallGetSelectMode(env_, instance);
    if (newMode != SelectMode::INVALID) {
        currentMode_.store(newMode);
    }
    
    return newMode;
}

std::string JsDeviceAbstractHelper::GetSelectModeString(SelectMode mode) const
{
    switch (mode) {
        case SelectMode::WIDE:
            return "WIDE";
        case SelectMode::SQUARE:
            return "SQUARE";
        default:
            return "INVALID";
    }
}

} // namespace OHOS::Rosen
