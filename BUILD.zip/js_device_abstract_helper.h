/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OHOS_WINDOW_JS_DEVICE_ABSTRACT_HELPER_H
#define OHOS_WINDOW_JS_DEVICE_ABSTRACT_HELPER_H

#include <atomic>
#include <mutex>
#include <string>
#include <native_engine/native_engine.h>
#include <native_engine/native_value.h>
#include <native_engine/native_reference.h>

namespace OHOS::Rosen {

/**
 * @brief Hook Mode 枚举（从 JS 侧同步）
 */
enum class SelectMode : int32_t {
    WIDE = 0,      // 宽屏模式
    SQUARE = 1,    // 方形模式
    INVALID = -1   // 无效值
};

/**
 * @brief JS DeviceAbstractHelper 单例的 NAPI 封装
 * 
 * 用于通过 NAPI 调用 JS 侧 DeviceAbstractHelper.getInstance().getSelectMode()
 * 线程安全，支持异步调用
 */
class JsDeviceAbstractHelper {
public:
    /**
     * @brief 获取单例对象
     */
    static JsDeviceAbstractHelper& GetInstance();
    
    /**
     * @brief 初始化 NAPI 环境（在模块加载时调用一次）
     * @param env NAPI 环境
     */
    void Initialize(napi_env env);
    
    /**
     * @brief 从 JS 侧获取最新的 SelectMode
     * @return SelectMode 枚举值
     */
    SelectMode GetSelectMode();
    
    /**
     * @brief 获取 SelectMode 的字符串表示
     */
    std::string GetSelectModeString(SelectMode mode) const;
    
private:
    JsDeviceAbstractHelper() = default;
    ~JsDeviceAbstractHelper();
    JsDeviceAbstractHelper(const JsDeviceAbstractHelper&) = delete;
    JsDeviceAbstractHelper& operator=(const JsDeviceAbstractHelper&) = delete;
    
    /**
     * @brief 调用 JS 侧 DeviceAbstractHelper.getInstance()
     */
    napi_value GetJSInstance(napi_env env);
    
    /**
     * @brief 调用 JS 侧 getSelectMode() 方法
     */
    SelectMode CallGetSelectMode(napi_env env, napi_value instance);
    
    // NAPI 引用（避免被 GC 回收）
    std::shared_ptr<NativeReference> jsModuleRef_;      // JS 模块引用
    std::shared_ptr<NativeReference> getInstanceFuncRef_; // getInstance 函数引用
    
    // NAPI 环境
    napi_env env_ = nullptr;
    
    // 当前 SelectMode（原子操作保证线程安全）
    std::atomic<SelectMode> currentMode_ = SelectMode::INVALID;
    
    // 是否已初始化
    std::atomic<bool> initialized_ = false;
    
    // 互斥锁（保护 NAPI 操作）
    mutable std::mutex napiMutex_;
};

} // namespace OHOS::Rosen

#endif // OHOS_WINDOW_JS_DEVICE_ABSTRACT_HELPER_H
